package controller;

import java.util.Vector;

import model.Participant;
import model.Tournament;
import view.TournamentView;
import listeners.TournamentListener;
import listeners.ViewListener;

public class TournamentController implements TournamentListener, ViewListener {
	private Tournament tournament;
	private TournamentView view;

	public TournamentController(Tournament tournament, TournamentView view) {
		this.tournament = tournament;
		this.view = view;
		view.registerListeners(this);
		tournament.registerListeners(this);
	}

	@Override
	public void fireParticipantsToUI(Vector<Participant> participants) {
		for (int i = 0; i < participants.size(); i++) {
			view.getAllTournamentNameLabels()[i].setText(participants.get(i).getName());
		}
	}

	@Override
	public void addParticipantToModel(String name) {
		try {
			tournament.addParticipantToTournament(name);
		} catch (Exception e) {
			view.getLblException().setText(e.getMessage());
			view.getLblException().setVisible(true);
		}

	}

	@Override
	public void startTournamentInModel(String gameType) {
		try {
			tournament.setGameType(gameType);
			tournament.startTournament();
		} catch (Exception e) {
			view.getLblException().setText(e.getMessage());
			view.getLblException().setVisible(true);
		}

	}

	@Override
	public void startGameInModel(String text, String text2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sumbitPartScoreInModel(int phaseNumber, int gameNumber, int scoreTeamA, int scoreTeamB) {
		// TODO Auto-generated method stub

	}

	@Override
	public void fireAddedPlayerToUI(String name) {
		boolean flag = false;
		for (int i = 0; i < view.getParticipantList().length && !flag; i++) {
			if (view.getParticipantList()[i].getText().isEmpty()) {
				flag = true;
				view.getParticipantList()[i].setText(name);
			}
		}
	}
}
