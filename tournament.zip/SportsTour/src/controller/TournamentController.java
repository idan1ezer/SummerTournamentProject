package controller;

import java.util.Vector;

import Games.Participant;
import Games.Tournament;
import TournamentView.TournamentView;
import listeners.TournamentListeners;
import listeners.ViewListeners;

public class TournamentController implements TournamentListeners, ViewListeners {
	private Tournament tournament;
	private TournamentView view;
	

	@Override
	public void fireNeed8Players() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fireMovingToNextPhase(Vector<Participant> winners) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addParticipantToModel(String name) {
		tournament.addParticipantToTournament(name);
		
	}

	@Override
	public void startTournamentInModel(String name) {
		tournament.startTournament();
		
	}
}
