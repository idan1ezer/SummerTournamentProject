package listeners;

public interface ViewListener {

	public void sumbitPartScoreInModel(int phaseNumber,int gameNumber,int scoreTeamA,int scoreTeamB);

	public void addParticipantToModel(String text) ;

	public void startTournamentInModel(String gameType);

	public void startGameInModel(String text, String text2);

}
