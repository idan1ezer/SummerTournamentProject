package controller;

import java.util.Vector;

import javax.swing.JOptionPane;

import javafx.scene.control.Label;
import model.Participant;
import model.Tournament;
import view.TournamentView;
import listeners.TournamentListener;
import listeners.ViewListener;

public class TournamentController implements TournamentListener, ViewListener {
	private Tournament tournament;
	private TournamentView view;

	public TournamentController(Tournament tournament, TournamentView view) {
		this.tournament = tournament;
		this.view = view;
		view.registerListeners(this);
		tournament.registerListeners(this);
	}

	@Override
	public void fireParticipantsToUI(Vector<Participant> participants) {
		for (int i = 0; i < participants.size(); i++) {
			view.getAllTournamentNameLabels()[i].setText(participants.get(i).getName());
		}
	}

	@Override
	public void addParticipantToModel(String name) {
		try {
			tournament.addParticipantToTournament(name);
		} catch (Exception e) {
			view.getLblException().setText(e.getMessage());
			view.getLblException().setVisible(true);
		}

	}

	@Override
	public void startTournamentInModel(String gameType) {
		try {
			tournament.setGameType(gameType);
			tournament.startTournament();
		} catch (Exception e) {
			view.getLblException().setText(e.getMessage());
			view.getLblException().setVisible(true);
		}

	}

	@Override
	public void submitPartScoreInModel(int gameIndex, int scoreTeamA, int scoreTeamB) {
		int part=0;
		try {
		if(gameIndex <=3) {
			part = tournament.getPhase().get(0).getGames().get(gameIndex).addScoreToTeams(scoreTeamA, scoreTeamB);
		}
		else if(gameIndex<=5)
			part = tournament.getPhase().get(0).getGames().get(gameIndex-4).addScoreToTeams(scoreTeamA, scoreTeamB);
		else
			part = tournament.getPhase().get(0).getGames().get(0).addScoreToTeams(scoreTeamA, scoreTeamB);
		
		}			
		
		catch (Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}


	@Override
	public void fireAddedPlayerToUI(String name) {
		boolean flag = false;
		for (int i = 0; i < view.getParticipantList().length && !flag; i++) {
			if (view.getParticipantList()[i].getText().isEmpty()) {
				flag = true;
				view.getParticipantList()[i].setText(name);
			}
		}
	}

	@Override
	public void startGameInModel(int gameIndex) {
		String participantA = null;
		String participantB = null;
		if (gameIndex <= 3) {
			participantA = tournament.getPhase().get(0).getGames().get(gameIndex).getTeamA().getName();
			participantB = tournament.getPhase().get(0).getGames().get(gameIndex).getTeamB().getName();
		} else if (gameIndex <= 5) {
			participantA = tournament.getPhase().get(1).getGames().get(gameIndex - 4).getTeamA().getName();
			participantB = tournament.getPhase().get(1).getGames().get(gameIndex - 4).getTeamB().getName();
		} else if (gameIndex <= 6) {
			participantA = tournament.getPhase().get(2).getGames().get(0).getTeamA().getName();
			participantB = tournament.getPhase().get(2).getGames().get(0).getTeamB().getName();
		}

		setParticipantsLabels(participantA, participantB);
	}

	private void setParticipantsLabels(String A, String B) {
		if (tournament.getGameType().getClass().getName() == "model.Soccer") {
			view.getTeamLabels()[0].setText(A);
			view.getTeamLabels()[1].setText(B);
		} else if (tournament.getGameType().getClass().getName() == "model.Basketball") {
			view.getTeamLabels()[2].setText(A);
			view.getTeamLabels()[3].setText(B);
		} else {
			view.getTeamLabels()[4].setText(A);
			view.getTeamLabels()[5].setText(B);
		}

		// CHANGE THE model. SHIT
	}
}
