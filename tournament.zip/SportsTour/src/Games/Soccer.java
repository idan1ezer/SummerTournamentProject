package Games;

import java.util.Scanner;

public class Soccer extends Game {
	private static int parts = 3;
	private boolean overtime;
	private boolean penalties;

	public Soccer() {
		super();
	}

	@Override
	public void startGame(Participant participant1, Participant participant2) {
		Scanner scan = new Scanner(System.in);
		
		participants.add(participant1);
		participants.add(participant2);

		for (int j = 0; j < 2; j++) {
			// System.out.println("Enter team " + participants.get(j).getName() + " score in " + (i + 1) + " half");
			participants.get(0).getScore().add(scan.nextInt());
			participants.get(1).getScore().add(scan.nextInt());
		}

		if (participants.get(0).getScore().elementAt(1) == participants.get(1).getScore().elementAt(1)) {
			overtime = true;
			participants.get(0).getScore().add(scan.nextInt());
			participants.get(1).getScore().add(scan.nextInt());

			if (participants.get(0).getScore().elementAt(2) == participants.get(1).getScore().elementAt(2)) {
				penalties = true;
				participants.get(0).getScore().add(scan.nextInt());
				participants.get(1).getScore().add(scan.nextInt());
			}
		}
	}


	@Override
	protected Participant getLoser() {
		if (penalties)
			return min(participants.get(0).getScore().get(3), participants.get(1).getScore().get(3));
		else if (overtime)
			return min(participants.get(0).getScore().get(2), participants.get(1).getScore().get(2));
		else
			return min(participants.get(0).getScore().get(1), participants.get(1).getScore().get(1));
			
	}

	private Participant min(Integer finalScoreTeamA, Integer finalScoreTeamB) {
		if(finalScoreTeamA > finalScoreTeamB)
			return participants.get(1);
		else
			return participants.get(0);
	}

}
