package view;

import java.util.Vector;

import model.Participant;
import listeners.ViewListener;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Effect;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class TournamentView extends Application {

	private static Vector<ViewListener> allListeners = new Vector<ViewListener>();
	Label[] participantList;
	Label[] allTournamentNameLabels;
	Label lblException = new Label();
	static BorderPane brRoot = new BorderPane();
	static StackPane spRoot = new StackPane();
	int tempIndex = 0;

	public Label getLblException() {
		return lblException;
	}

	public TournamentView(Stage theStage) {
		lblException.setVisible(false);
		brRoot.setPadding(new Insets(20));
		brRoot.setCenter(spRoot);
		spRoot.setAlignment(Pos.CENTER);

		Label lblName = new Label("Paticipent Name:");
		TextField tfPlayerName = new TextField();
		Button btnAddParticipet = new Button("Add Participent");
		Button btnStartTournament = new Button("Start Tournament");

		GridPane gpAddPlayers = new GridPane();
		gpAddPlayers.setPadding(new Insets(20));
		gpAddPlayers.setVgap(10);
		gpAddPlayers.setHgap(10);
		gpAddPlayers.setAlignment(Pos.CENTER);
		gpAddPlayers.add(lblName, 0, 0);
		gpAddPlayers.add(tfPlayerName, 1, 0);
		gpAddPlayers.add(btnAddParticipet, 0, 1);
		gpAddPlayers.add(btnStartTournament, 1, 1);

		RadioButton rbSportTypeSoccer = new RadioButton("Soccer");
		RadioButton rbSportTypeBasketball = new RadioButton("Basketball");
		RadioButton rbSportTypeTennis = new RadioButton("Tennis");
		ToggleGroup tglGames = new ToggleGroup();
		rbSportTypeSoccer.setToggleGroup(tglGames);
		rbSportTypeBasketball.setToggleGroup(tglGames);
		rbSportTypeTennis.setToggleGroup(tglGames);
		RadioButton[] rdGroup = { rbSportTypeSoccer, rbSportTypeBasketball, rbSportTypeTennis };

		VBox vbChooseGame = new VBox();
		vbChooseGame.setPadding(new Insets(20));
		vbChooseGame.setSpacing(20);
		vbChooseGame.setAlignment(Pos.CENTER_LEFT);
		vbChooseGame.getChildren().addAll(rbSportTypeSoccer, rbSportTypeBasketball, rbSportTypeTennis);

		Label lblParticipent1 = new Label();
		Label lblParticipent2 = new Label();
		Label lblParticipent3 = new Label();
		Label lblParticipent4 = new Label();
		Label lblParticipent5 = new Label();
		Label lblParticipent6 = new Label();
		Label lblParticipent7 = new Label();
		Label lblParticipent8 = new Label();

		VBox vbParticipents = new VBox();
		vbParticipents.setPadding(new Insets(20));
		vbParticipents.setSpacing(30);
		vbParticipents.setAlignment(Pos.CENTER_LEFT);

		vbParticipents.getChildren().addAll(lblParticipent1, lblParticipent2, lblParticipent3, lblParticipent4,
				lblParticipent5, lblParticipent6, lblParticipent7, lblParticipent8);

		Label[] lblPlayers8 = { lblParticipent1, lblParticipent2, lblParticipent3, lblParticipent4, lblParticipent5,
				lblParticipent6, lblParticipent7, lblParticipent8 };

		for (int i = 0; i < lblPlayers8.length; i++) {
			lblPlayers8[i].setMinWidth(80);
			lblPlayers8[i].setMaxWidth(80);
			lblPlayers8[i].setMinHeight(20);
			lblPlayers8[i].setMaxHeight(20);
		}

		participantList = lblPlayers8;

		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(10.0);
		dropShadow.setOffsetX(5.0);
		dropShadow.setOffsetY(3.0);
		dropShadow.setColor(Color.color(0.4, 0.5, 0.5));

		for (int i = 0; i < lblPlayers8.length; i++) {
			lblPlayers8[i].setBorder(new Border(
					new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
			lblPlayers8[i]
					.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
			lblPlayers8[i].setTextFill(Color.BLACK);
			lblPlayers8[i].setFont(new Font(STYLESHEET_CASPIAN, 15));
			lblPlayers8[i].setEffect(dropShadow);
		}

		GridPane gpTournamentPhases = new GridPane();
		gpTournamentPhases.setPadding(new Insets(10));
		gpTournamentPhases.setVgap(0);
		gpTournamentPhases.setHgap(40);
		gpTournamentPhases.setAlignment(Pos.CENTER_LEFT);
		gpTournamentPhases.setVisible(false);

		Label lblPhase0Participent1 = new Label("	1	");
		Label lblPhase0Participent2 = new Label("	2	");
		Label lblPhase0Participent3 = new Label("	3	");
		Label lblPhase0Participent4 = new Label("	4	");
		Label lblPhase0Participent5 = new Label("	5	");
		Label lblPhase0Participent6 = new Label("	6	");
		Label lblPhase0Participent7 = new Label("	7	");
		Label lblPhase0Participent8 = new Label("	8	");

		Button btnPhase1PlayGame1 = new Button("Play Game");
		Button btnPhase1PlayGame2 = new Button("Play Game");
		Button btnPhase1PlayGame3 = new Button("Play Game");
		Button btnPhase1PlayGame4 = new Button("Play Game");
		Label lblWinnerPhase1Game1 = new Label("	1	");
		Label lblWinnerPhase1Game2 = new Label("	3	");
		Label lblWinnerPhase1Game3 = new Label("	5	");
		Label lblWinnerPhase1Game4 = new Label("	7	");

		Button btnPhase2PlayGame1 = new Button("Play Game");
		Button btnPhase2PlayGame2 = new Button("Play Game");
		Label lblWinnerPhase2Game1 = new Label("	1	");
		Label lblWinnerPhase2Game2 = new Label("	5	");

		Button btnFinalPlayGame = new Button("Play Game");
		Label lblWinner = new Label("	1	");

		gpTournamentPhases.add(lblPhase0Participent1, 0, 0);
		gpTournamentPhases.add(lblPhase0Participent2, 0, 2);
		gpTournamentPhases.add(lblPhase0Participent3, 0, 4);
		gpTournamentPhases.add(lblPhase0Participent4, 0, 6);
		gpTournamentPhases.add(lblPhase0Participent5, 0, 8);
		gpTournamentPhases.add(lblPhase0Participent6, 0, 10);
		gpTournamentPhases.add(lblPhase0Participent7, 0, 12);
		gpTournamentPhases.add(lblPhase0Participent8, 0, 14);
		gpTournamentPhases.add(btnPhase1PlayGame1, 1, 1);
		gpTournamentPhases.add(btnPhase1PlayGame2, 1, 5);
		gpTournamentPhases.add(btnPhase1PlayGame3, 1, 9);
		gpTournamentPhases.add(btnPhase1PlayGame4, 1, 13);
		gpTournamentPhases.add(lblWinnerPhase1Game1, 2, 1);
		gpTournamentPhases.add(lblWinnerPhase1Game2, 2, 5);
		gpTournamentPhases.add(lblWinnerPhase1Game3, 2, 9);
		gpTournamentPhases.add(lblWinnerPhase1Game4, 2, 13);
		gpTournamentPhases.add(btnPhase2PlayGame1, 3, 3);
		gpTournamentPhases.add(btnPhase2PlayGame2, 3, 11);
		gpTournamentPhases.add(lblWinnerPhase2Game1, 4, 3);
		gpTournamentPhases.add(lblWinnerPhase2Game2, 4, 11);
		gpTournamentPhases.add(btnFinalPlayGame, 5, 7);
		gpTournamentPhases.add(lblWinner, 6, 7);

		Label[] allLabels = { lblPhase0Participent1, lblPhase0Participent2, lblPhase0Participent3,
				lblPhase0Participent4, lblPhase0Participent5, lblPhase0Participent6, lblPhase0Participent7,
				lblPhase0Participent8, lblWinnerPhase1Game1, lblWinnerPhase1Game2, lblWinnerPhase1Game3,
				lblWinnerPhase1Game4, lblWinnerPhase2Game1, lblWinnerPhase2Game2, lblWinner };
		allTournamentNameLabels = allLabels;

		for (int i = 0; i < allTournamentNameLabels.length; i++) {
			allTournamentNameLabels[i].setBorder(new Border(
					new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
			allTournamentNameLabels[i]
					.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
			allTournamentNameLabels[i].setTextFill(Color.BLACK);
			allTournamentNameLabels[i].setFont(new Font(STYLESHEET_CASPIAN, 15));
			allTournamentNameLabels[i].setEffect(dropShadow);
			allTournamentNameLabels[i].setMinWidth(80);
			allTournamentNameLabels[i].setMaxWidth(80);
			allTournamentNameLabels[i].setMinHeight(20);
			allTournamentNameLabels[i].setMaxHeight(20);
		}

		brRoot.setRight(vbChooseGame);
		brRoot.setLeft(vbParticipents);
		brRoot.setBottom(lblException);
		spRoot.getChildren().addAll(gpAddPlayers, gpTournamentPhases);

//Play Game PopUps - Soccer
		BorderPane bpSoccer = new BorderPane();

		VBox vbSoccerScene = new VBox();
		vbSoccerScene.setPadding(new Insets(10));
		vbSoccerScene.setSpacing(10);

		HBox hbSoccerSceneHeadlines = new HBox();
		hbSoccerSceneHeadlines.setPadding(new Insets(10));
		hbSoccerSceneHeadlines.setSpacing(25);

		HBox hbSoccerTeamAScores = new HBox();
		hbSoccerTeamAScores.setPadding(new Insets(10));
		hbSoccerTeamAScores.setSpacing(20);

		HBox hbSoccerTeamBScores = new HBox();
		hbSoccerTeamBScores.setPadding(new Insets(10));
		hbSoccerTeamBScores.setSpacing(20);

		HBox hbSoccerEndingButtons = new HBox();
		hbSoccerEndingButtons.setPadding(new Insets(10));
		hbSoccerEndingButtons.setSpacing(10);

		Label lblSoccerHeadline = new Label("Soccer");
		Label lblSoccerPlayer1 = new Label("TeamA");
		Label lblSoccerPlayer2 = new Label("TeamB");
		Label lblSoccerHalf1 = new Label("Half 1");
		Label lblSoccerHalf2 = new Label("Half 2");
		Label lblSoccerOvertime = new Label("Overtime");
		Label lblSoccerPenalties = new Label("Penalties");

		TextField tfSoccerTeamAScoreHalf1 = new TextField();
		TextField tfSoccerTeamBScoreHalf1 = new TextField();
		TextField tfSoccerTeamAScoreHalf2 = new TextField();
		TextField tfSoccerTeamBScoreHalf2 = new TextField();
		TextField tfSoccerTeamAScoreOvertime = new TextField();
		TextField tfSoccerTeamBScoreOvertime = new TextField();
		TextField tfSoccerTeamAScorePenalties = new TextField();
		TextField tfSoccerTeamBScorePenalties = new TextField();
		TextField[] soccerTextFields = { tfSoccerTeamAScoreHalf1, tfSoccerTeamBScoreHalf1, tfSoccerTeamAScoreHalf2,
				tfSoccerTeamBScoreHalf2, tfSoccerTeamAScoreOvertime, tfSoccerTeamBScoreOvertime,
				tfSoccerTeamAScorePenalties, tfSoccerTeamBScorePenalties };

		for (int i = 0; i < soccerTextFields.length; i++) {
			soccerTextFields[i].setMaxWidth(40);
		}
		
		Button btnSoccerSubmitScore = new Button("Submit Score");
		Button btnSoccerDone = new Button("Done");

		hbSoccerSceneHeadlines.getChildren().addAll(lblSoccerHeadline,lblSoccerHalf1, lblSoccerHalf2, lblSoccerOvertime,
				lblSoccerPenalties);
		hbSoccerTeamAScores.getChildren().addAll(lblSoccerPlayer1, tfSoccerTeamAScoreHalf1, tfSoccerTeamAScoreHalf2,
				tfSoccerTeamAScoreOvertime, tfSoccerTeamAScorePenalties);
		hbSoccerTeamBScores.getChildren().addAll(lblSoccerPlayer2, tfSoccerTeamBScoreHalf1, tfSoccerTeamBScoreHalf2,
				tfSoccerTeamBScoreOvertime, tfSoccerTeamBScorePenalties);
		hbSoccerEndingButtons.getChildren().addAll(btnSoccerSubmitScore, btnSoccerDone);

		vbSoccerScene.getChildren().addAll(hbSoccerSceneHeadlines, hbSoccerTeamAScores, hbSoccerTeamBScores);
		bpSoccer.setCenter(vbSoccerScene);
		//bpSoccer.setTop(lblSoccerHeadline);
		bpSoccer.setBottom(hbSoccerEndingButtons);

		Stage gameStage = new Stage();
		Scene soccerScene = new Scene(bpSoccer, 500, 300);

//buttons setOnActions
		btnAddParticipet.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (tfPlayerName.getText() != null) {
					for (ViewListener l : allListeners) {
						l.addParticipantToModel(tfPlayerName.getText());
					}
					// tfPlayerName.clear(); delete the // when finish
				}
			}
		});

		btnStartTournament.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (tglGames.getSelectedToggle() != null && lblPlayers8.length==8) {
					for (int i = 0; i < allTournamentNameLabels.length; i++) {
						allTournamentNameLabels[i].setText(null);
					}
					lblException.setVisible(false);
					gpAddPlayers.setVisible(false);
					vbChooseGame.setVisible(false);
					vbParticipents.setVisible(false);
					gpTournamentPhases.setVisible(true);
					String name = "not working";
					for (RadioButton l : rdGroup) {
						if (l.isSelected())
							name = l.getText();
					}
					for (ViewListener l : allListeners) {
						l.startTournamentInModel(name);
					}
				} else {
					lblException.setText("must choose a game / must have 8 Participants");
					lblException.setVisible(true);
				}
			}
		});

		Button[] allPlayGameButttons = { btnPhase1PlayGame1, btnPhase1PlayGame2, btnPhase1PlayGame3, btnPhase1PlayGame4,
				btnPhase2PlayGame1, btnPhase2PlayGame2, btnFinalPlayGame };

		for (int i = 0; i < allPlayGameButttons.length; i++) {
			tempIndex = i;
			allPlayGameButttons[i].setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent event) {
					gameStage.setScene(soccerScene);
					gameStage.show();
					for (ViewListener l : allListeners)
						l.startGameInModel(allTournamentNameLabels[tempIndex * 2].getText(),
								allTournamentNameLabels[tempIndex * 2 + 1].getText());
				}
			});
		}

		Scene scene = new Scene(brRoot, 1300, 700);
		theStage.setScene(scene);
		theStage.show();
	}

	@Override
	public void start(Stage theStage) throws Exception {
		// TODO Auto-generated method stub

	}

	public Label[] getAllTournamentNameLabels() {
		return allTournamentNameLabels;
	}

	public Label[] getParticipantList() {
		return participantList;
	}

	public void registerListeners(ViewListener newListener) {
		allListeners.add(newListener);
	}
}
