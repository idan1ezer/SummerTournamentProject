package Games;

import java.util.Vector;

public class Tournament {
	private Vector<Participant> participants = new Vector<Participant>();
	//private Vector<Phase> phases = new Vector<Phase>();
	private Game game;

	public Tournament(Game game) {
		if (game instanceof Soccer)
			this.game = new Soccer();
		else if (game instanceof Basketball)
			this.game = new Basketball();
		else if (game instanceof Tennis)
			this.game = new Tennis();
	}
	
	public Tournament(String game) {
		if(game.equals("Soccer"))
			this.game = new Soccer();
		else if(game.equals("Basketball"))
			this.game = new Basketball();
		else
			this.game = new Tennis();
	}

	public void addParticipantToTournament(String name) {
		if (participants.capacity() <= 8)
			participants.add(new Participant(name));
		else
			System.out.println("There is no free spot");
	}

	public void startTournament() {
		if (participants.capacity() != 8) {
			System.out.println("Need to have exactly 8 participants before starting a tournament");
		Phase phase1 = new Phase(4, game, participants);
		for (Participant i : participants) {
			phase1.getParticipants().add(i);
		}
		phase1.startPhase();
		
		Phase phase2 = new Phase(2, game, phase1.getParticipants());
		phase2.startPhase();
		
		Phase phase3 = new Phase(1, game, phase2.getParticipants());
		phase3.startPhase();

		Participant winner = phase3.getParticipants().get(0);
		}
	}

}
