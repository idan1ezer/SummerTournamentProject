package model;

import java.util.Vector;

import javax.swing.JOptionPane;

import listeners.TournamentListener;

public class Tournament {
	private static Vector<TournamentListener> allListeners = new Vector<TournamentListener>();
	private Vector<Participant> participants = new Vector<Participant>();
	private Vector<Phase> phase = new Vector<Phase>();
	private Game gameType;
	private int phaseIndex;
	private int gameIndex;
	private int part;

	public Tournament() {
	}

	public void registerListeners(TournamentListener newListener) {
		allListeners.add(newListener);
	}

	public void addParticipantToTournament(String name) throws Exception {
		if (participants.size() < 8) {// change the number to a final int
			participants.add(new Participant(name));
			for (TournamentListener l : allListeners) {
				l.fireAddedPlayerToUI(name);
			}
		} else {
			throw new Exception("There are Already 8 Participants");
		}
	}

	public void startTournament() throws Exception {
		if (participants.size() > 8)
			throw new Exception("Need to have exactly 8 participants before starting a tournament");// not relevant
																									// anymore
		phase.add(new Phase(4, gameType, participants));
		for (TournamentListener l : allListeners)
			l.fireParticipantsToUI(participants);
		phase.get(0).startPhase();
	}

	// consider using this instead of asking directly Soccer/Basketball/Tennis
	public void submitPartScore(int gameIndex, int scoreTeamA, int scoreTeamB) {
		part=0;
		try {
		if(gameIndex <=3) {//by the game index we created in the view we can learn the exacly phase&game it points to
			part = getPhase().get(0).getGames().get(gameIndex).addScoreToTeams(scoreTeamA, scoreTeamB);
			phaseIndex=0;
			}
		else if(gameIndex<=5) {//semi finals
			part = getPhase().get(1).getGames().get(gameIndex-4).addScoreToTeams(scoreTeamA, scoreTeamB);
			phaseIndex=1;
			this.gameIndex=gameIndex-4;
		}
		else{//finals
			part = getPhase().get(2).getGames().get(0).addScoreToTeams(scoreTeamA, scoreTeamB);
			phaseIndex=2;
			this.gameIndex=0;
		}
		checkResults();
		
		
		}			
		
		catch (Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		
	}

	private void checkResults() {
		if(phase.get(phaseIndex).getGames().get(gameIndex).checkForWinner()) {//change checkForWinner To Boolean
			removeLoser(phase.get(phaseIndex).getGames().get(gameIndex).getLoser());
			for (TournamentListener l:allListeners)
				l.fireWinnerToUI(phase.get(phaseIndex).getGames().get(gameIndex).getWinner());
			}
		else {
			for (TournamentListener l:allListeners)
				l.fireNextTextFieldsToUI(part);
		}
			
			
			
		}
		
		
		
		
		
		
		
	

	private void removeLoser(Participant loser) {
		for (int i = 0; i < participants.capacity(); i++) {
			if(participants.get(i).equals(loser)) {
				participants.remove(i);
				System.out.println("delete"+i);
			}
		}
		
		
	}

	private void checkForWinner(int phaseNum, int gameIndex) {
		getPhase().get(phaseNum).getGames().get(gameIndex).getLoser();
	}

	public void setGameType(String game) throws Exception {
		if (game == null) {
			throw new Exception("must choose game type");
		}
		if (game.equals("Soccer"))
			this.gameType = new Soccer();
		
		  //else if(game.equals("Basketball")) this.gameType= new Basketball(); 
		  //else
			//  this.gameType = new Tennis();
		 
	}

	public Vector<Phase> getPhase() {
		return phase;
	}

	public Game getGameType() {
		return gameType;
	}
	
	public String getGameTypeName() {
		return gameType.toString();
	}
	
	
	

}
