package Games;

import TournamentView.TournamentView;
import javafx.application.Application;
import javafx.stage.Stage;

public class Program extends Application {
	
	public void start(Stage theStage) {
		TournamentView view = new TournamentView(theStage);
		
	}

	public static void main(String[] args) {
		launch(args);	
	}

}
