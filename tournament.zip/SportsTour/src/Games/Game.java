package Games;

import java.util.Vector;

public abstract class Game {
	protected int parts;
	protected Vector <Participant> participants;
	protected int finalScore;
	
	protected boolean coinFlip; // Tales / heads
	
	public Game() {
		
	}
	
	
	protected abstract void startGame(Participant participant, Participant participant2);

	protected abstract Participant getLoser();
	
	
	
	
	
}
