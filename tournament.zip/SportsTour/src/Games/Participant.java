package Games;

import java.util.Vector;

public class Participant {
	private String name;
	private int wins;
	private Vector<Integer> score = new Vector<Integer>();
	
	public Participant(String name) {
		this.name = name;
		this.wins = 0;
	}

	public String getName() {
		return name;
	}

	public Vector<Integer> getScore() {
		return score;
	}

	public void setScore(Vector<Integer> score) {
		this.score = score;
	}
	
	
	
	
	
}
