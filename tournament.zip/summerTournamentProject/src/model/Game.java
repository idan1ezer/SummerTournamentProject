package model;

public abstract class Game {
	protected int parts;
	protected Participant teamA;
	protected Participant teamB;
	
	public Game() {
		
	}
		
	protected abstract Participant getLoser();

	public void setPlayers(Participant player1, Participant player2) {
		teamA=player1;
		teamB=player2;
	}
	
	public Participant getTeamA() {
		return teamA;
	}

	public Participant getTeamB() {
		return teamB;
	}

	public abstract int addScoreToTeams(int scoreA, int scoreB) throws Exception;

	public int getParts() {
		return parts;
	}

	@Override
	public abstract String toString();

	protected abstract void checkForWinner();
	
	
	
}
