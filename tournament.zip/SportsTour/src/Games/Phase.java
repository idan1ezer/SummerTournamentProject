package Games;

import java.util.Vector;

public class Phase {
	private Vector <Game> games = new Vector<Game>();
	private Vector <Participant> participants;
	
	
	public Phase(int numOfGames, Game game, Vector <Participant> participants) {
		
		for (int i = 0; i < numOfGames; i++) {
			if(game instanceof Soccer)
				games.add(new Soccer());
			else if(game instanceof Basketball)
				games.add(new Basketball());
			else if(game instanceof Tennis)//only else
				games.add(new Tennis());
		}
		this.participants = participants;
	}

	public void startPhase() {
		
		for (int i = 0; i < games.capacity(); i++) {
			games.get(i).startGame(participants.get(2*i), participants.get(2*i + 1));
			removeParticipant(games.get(i).getLoser());
		}
	}
	
	public void removeParticipant(Participant loser) {
		boolean found = false;
		for (int i = 0; i < participants.capacity() && !found; i++) {
			if(participants.get(i).equals(loser)) {
				participants.remove(i);
				found = true;
			}
		}
	}
	
	

	public Vector<Participant> getParticipants() {
		return participants;
	}
	
	
	
}
