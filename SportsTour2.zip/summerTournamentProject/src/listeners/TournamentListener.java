package listeners;

import java.util.Vector;

import model.Participant;

public interface TournamentListener {

	void fireParticipantsToUI(Vector<Participant> participants);

	void fireAddedPlayerToUI(String name);
	
	
}
