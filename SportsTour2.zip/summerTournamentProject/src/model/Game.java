package model;

public abstract class Game {
	protected int parts;
	protected Participant teamA;
	protected Participant teamB;
	
	public Game() {
		
	}
	
	

	protected abstract Participant getLoser();


	public void setPlayers(Participant player1, Participant player2) {
		teamA=player1;
		teamB=player2;
	}


	protected abstract void addScoreTeamA(int scoreA);
	
	protected abstract void addScoreTeamB(int scoreB);
	
	
	
	
	
}
