package model;

import java.util.Vector;

import listeners.TournamentListener;

public class Tournament {
	private static Vector<TournamentListener> allListeners = new Vector<TournamentListener>();
	private Vector<Participant> participants = new Vector<Participant>();
	private Vector<Phase> phase = new Vector<Phase>();
	private Game gameType;

	public Tournament() {
	}

	public void registerListeners(TournamentListener newListener) {
		allListeners.add(newListener);
	}

	public void addParticipantToTournament(String name) throws Exception {
		if (participants.size() < 8) {// change the number to a final int
			participants.add(new Participant(name));
			for (TournamentListener l : allListeners) {
				l.fireAddedPlayerToUI(name);
			}
		} else {
			throw new Exception("There are Already 8 Participants");
		}
	}

	public void startTournament() throws Exception {
		if (participants.size() > 8)
			throw new Exception("Need to have exactly 8 participants before starting a tournament");// not relevant
																									// anymore
		phase.add(new Phase(4, gameType, participants));
		for (TournamentListener l : allListeners)
			l.fireParticipantsToUI(participants);
		phase.get(0).startPhase();
	}

	// consider using this instead of asking directly Soccer/Basketball/Tennis
	public void submitPartScore(int phaseNum, int gameNum, int scoreTeamA, int scoreTeamB) throws Exception {
		phase.get(phaseNum - 1).getGames().get(gameNum - 1).addScoreToTeams(scoreTeamA, scoreTeamB);
	}

	public void setGameType(String game) throws Exception {
		if (game == null) {
			throw new Exception("must choose game type");
		}
		if (game.equals("Soccer"))
			this.gameType = new Soccer();
		
		  //else if(game.equals("Basketball")) this.gameType= new Basketball(); 
		  //else
			//  this.gameType = new Tennis();
		 
	}

	public Vector<Phase> getPhase() {
		return phase;
	}

	public Game getGameType() {
		return gameType;
	}
	
	public String getGameTypeName() {
		return gameType.toString();
	}
	
	
	

}
