package model;

import java.util.Random;

public abstract class Game {
	protected int baseParts;
	protected int extraParts;
	protected Participant winner;
	protected Participant looser;
	protected Participant teamA;
	protected Participant teamB;
	
	public Game() {
		
	}
	public void setPlayers(Participant player1, Participant player2) {
		teamA=player1;
		teamB=player2;
	}
	
	public abstract int addScoreToTeams(int scoreA, int scoreB) throws Exception;
	
	protected abstract boolean checkForWinner(int part);
	
	protected abstract void setWinnerAndLoser();
	
	public Participant getTeamA() {
		return teamA;
	}

	public Participant getTeamB() {
		return teamB;
	}

	public int getBaseParts() {
		return baseParts;
	}
	
	public int getExtraParts() {
		return extraParts;
	}
	

	public Participant getWinner() {
		return winner;
	}
	public Participant getLoser() {
		return looser;
	}
	
	@Override
	public abstract String toString();
	
	protected abstract boolean draw();
	
	public void coinFlip() {
		Random rd = new Random();
		boolean coin = rd.nextBoolean();
		if (coin) {
			winner=teamA;
			looser=teamB;
		}
		else {
			winner=teamB;
			looser=teamA;
		}
	}	
	
}
