package model;

public class Basketball extends Game {
	
	private boolean overtime;

	public Basketball() {
		super();
		baseParts = 4;
		extraParts = 1;
	}

	@Override
	public int addScoreToTeams(int scoreA, int scoreB) throws Exception {
		addScoreToTeam(teamA, scoreA);
		addScoreToTeam(teamB, scoreB);
		if (teamA.getScore().size() >= baseParts) {
			System.out.println("end game / overtime ");
			if (checkForWinner(teamA.getScore().size())) {
				return 99;
			}
			System.out.println("5");
		}
		System.out.println(teamA.getScore().size());
		return teamA.getScore().size();
	}

	protected boolean checkForWinner(int partNum) {
		int fixPartNum = partNum - 1;
		System.out.println("fixnum " + fixPartNum);
		if (teamA.getScore().get(fixPartNum) != teamB.getScore().get(fixPartNum)) {
			setWinnerAndLoser();
			System.out.println("checkForWinner in if");
			return true;
		} else if (teamA.getScore().get(baseParts - 1) == teamB.getScore().get(baseParts - 1)) {
			overtime = true;
		}
		return false;

	}

	protected void setWinnerAndLoser() {
		if (overtime)
			checkAndSet(sumParts(teamA,baseParts),sumParts(teamB,baseParts));
		else
			checkAndSet(sumParts(teamA,baseParts-1),sumParts(teamB,baseParts-1));

		teamA.getScore().clear();
		teamB.getScore().clear();

	}

	

	private int sumParts(Participant team, int partsNum) {
		int totalScore =0;
		for (int i = 0; i <partsNum; i++) {
			totalScore+=team.getScore().get(i);
		}
		return totalScore;
	}

	private void checkAndSet(int finalScoreTeamA, int finalScoreTeamB) {
		if (finalScoreTeamA > finalScoreTeamB) {
				winner = teamA;
				looser = teamB;
		} else {
			winner = teamB;
			looser = teamA;
		}
	}

	private void addScoreToTeam(Participant team, int score) throws Exception {
		if (score >= 0 && score < 100) {
			if (team.getScore().size() <= baseParts+1) {
				team.addScore(score);
			}
		} else {
			throw new Exception("the score entered is not possible, fix the number");
		}
	}

	/*
	 * public void enableOvertimeOrPenalties() {
	 * 
	 * if (teamA.getScore().get(1) == teamB.getScore().get(1)) overtime = true;
	 * 
	 * if (teamA.getScore().size() == 3 && teamA.getScore().get(2) ==
	 * teamB.getScore().get(2)) { overtime = false; penalties = true; } }
	 */

	@Override
	public String toString() {
		return "Basketball";
	}

	@Override
	protected boolean draw() {
		if (overtime&&teamA.getScore().get(baseParts+extraParts-1)==teamB.getScore().get(baseParts+extraParts-1)) {
			return true;
		}
		return false;
	}
}
