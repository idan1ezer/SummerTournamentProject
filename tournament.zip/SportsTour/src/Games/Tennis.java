package Games;

public class Tennis extends Game {
	private static int parts = 5;
	
	
	@Override
	public void individualPart() {
		// TODO Auto-generated method stub

	}

}
