package listeners;

import java.util.Vector;

import Games.Participant;

public interface TournamentListeners {
	
	void fireNeed8Players();
	void fireMovingToNextPhase(Vector<Participant> winners);
}
