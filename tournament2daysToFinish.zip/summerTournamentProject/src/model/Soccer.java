package model;


public class Soccer extends Game {
	private boolean overtime;
	private boolean penalties;

	public Soccer() {
		super();
		baseParts = 2;
		extraParts = 2;
	}



	@Override
	public int addScoreToTeams(int scoreA, int scoreB) throws Exception {
		System.out.println("1");
		addScoreToTeam(teamA, scoreA);
		System.out.println("2");
		addScoreToTeam(teamB, scoreB);
		System.out.println("3");

		if (teamA.getScore().size() >= baseParts) {
			System.out.println("end game / overtime / penalties");
			if(checkForWinner(teamA.getScore().size())) {
				return 99;
			}
			System.out.println("5");
		}
		System.out.println(teamA.getScore().size());
		return teamA.getScore().size();
	}

	
	protected boolean checkForWinner(int partNum) {
		System.out.println("checkforwinner");
		int fixPartNum = partNum - 1;
		System.out.println("fixnum " + fixPartNum);
		if (teamA.getScore().get(fixPartNum) != teamB.getScore().get(fixPartNum)) {
			setWinnerAndLoser();
			System.out.println("checkForWinner in if");
			return true;
		} else if (teamA.getScore().get(baseParts-1) == teamB.getScore().get(baseParts-1)) {
			overtime = true;
		}if (teamA.getScore().size() == 3 && teamA.getScore().get(baseParts) == teamB.getScore().get(baseParts)) {
			overtime = false;
			penalties = true;
		}
		return false;

	}
	
	protected void setWinnerAndLoser() {
		if (penalties) {
			checkAndSet(teamA.getScore().get(3), teamB.getScore().get(3));
		} else if (overtime)
			checkAndSet(teamA.getScore().get(2), teamB.getScore().get(2));
		else
			checkAndSet(teamA.getScore().get(1), teamB.getScore().get(1));

		teamA.getScore().clear();
		teamB.getScore().clear();

	}

	private void checkAndSet(int finalScoreTeamA, int finalScoreTeamB) {
		if (finalScoreTeamA > finalScoreTeamB) {
			winner = teamA;
			looser = teamB;
		} else {
			winner = teamB;
			looser = teamA;
		}
	}

	private void addScoreToTeam(Participant team, int score) throws Exception {
		if (score >= 0) {
			if (team.getScore().size() == 0)
				team.addScore(score);
			else if (team.getScore().size() == 1) {
				if (score >= team.getScore().get(0))
					team.addScore(score);
				else {
					throw new Exception("Score must be higher than first half");
				}
			} else if (team.getScore().size() == 2) {
				if (score >= team.getScore().get(1))
					team.addScore(score);
				else {
					throw new Exception("Score must be higher than second half");
				}
			} else if (team.getScore().size() == 3) {
				if (score <= 5)
					team.addScore(score);
				else {
					throw new Exception("Penalties score must be lower or equal to 5");
				}
			}

		}
	}

	/*
	 * public void enableOvertimeOrPenalties() {
	 * 
	 * if (teamA.getScore().get(1) == teamB.getScore().get(1)) overtime = true;
	 * 
	 * if (teamA.getScore().size() == 3 && teamA.getScore().get(2) ==
	 * teamB.getScore().get(2)) { overtime = false; penalties = true; } }
	 */
	
	@Override
	public String toString() {
		return "Soccer";
	}



	@Override
	protected boolean draw() {
		System.out.println("before 3");
		System.out.println(teamA.getScore().get(3));
		System.out.println("after 3");
		if (penalties&&teamA.getScore().get(baseParts+extraParts-1)==teamB.getScore().get(baseParts+extraParts-1)) {
			System.out.println("soccer draw");
			return true;
		}
		return false;
	}

}
