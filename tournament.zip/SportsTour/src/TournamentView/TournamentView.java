package TournamentView;

import java.util.Vector;

import listeners.ViewListeners;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class TournamentView extends Application {

	private static Vector<ViewListeners> allListeners = new Vector<ViewListeners>();
	static BorderPane brRoot = new BorderPane();
	static StackPane spRoot = new StackPane();

	public TournamentView(Stage theStage) {

		brRoot.setPadding(new Insets(20));
		brRoot.setCenter(spRoot);
		spRoot.setAlignment(Pos.CENTER);

		VBox vbChooseGame = new VBox();
		vbChooseGame.setPadding(new Insets(20));
		vbChooseGame.setSpacing(20);

		Label lblName = new Label("Paticipent Name:");
		TextField tfPlayerName = new TextField();
		Button btnAddParticipet = new Button("Add Participent");
		Button btnStartTournament = new Button("Start Tournament");

		GridPane gpAddPlayers = new GridPane();
		gpAddPlayers.setPadding(new Insets(20));
		gpAddPlayers.setVgap(10);
		gpAddPlayers.setHgap(10);
		gpAddPlayers.setAlignment(Pos.CENTER);
		gpAddPlayers.add(lblName, 0, 0);
		gpAddPlayers.add(tfPlayerName, 1, 0);
		gpAddPlayers.add(btnAddParticipet, 0, 1);
		gpAddPlayers.add(btnStartTournament, 1, 1);

		ToggleGroup tglGames = new ToggleGroup();
		RadioButton rbSportTypeSoccer = new RadioButton("Soccer");
		RadioButton rbSportTypeBasketball = new RadioButton("Basketball");
		RadioButton rbSportTypeTennis = new RadioButton("Tennis");
		rbSportTypeSoccer.setToggleGroup(tglGames);
		rbSportTypeBasketball.setToggleGroup(tglGames);
		rbSportTypeTennis.setToggleGroup(tglGames);

		VBox vbParticipents = new VBox();
		vbParticipents.setPadding(new Insets(20));
		vbParticipents.setSpacing(30);

		GridPane gpPhase = new GridPane();
		gpPhase.setPadding(new Insets(10));
		gpPhase.setVgap(0);
		gpPhase.setHgap(40);

		Label lblParticipent1 = new Label("	1	");
		Label lblParticipent2 = new Label("	2	");
		Label lblParticipent3 = new Label("	3	");
		Label lblParticipent4 = new Label("	4	");
		Label lblParticipent5 = new Label("	5	");
		Label lblParticipent6 = new Label("	6	");
		Label lblParticipent7 = new Label("	7	");
		Label lblParticipent8 = new Label("	8	");

		Label lblPhase0Participent1 = new Label("	1	");
		Label lblPhase0Participent2 = new Label("	2	");
		Label lblPhase0Participent3 = new Label("	3	");
		Label lblPhase0Participent4 = new Label("	4	");
		Label lblPhase0Participent5 = new Label("	5	");
		Label lblPhase0Participent6 = new Label("	6	");
		Label lblPhase0Participent7 = new Label("	7	");
		Label lblPhase0Participent8 = new Label("	8	");

		Button btnPhase1PlayGame1 = new Button("Play Game");
		Button btnPhase1PlayGame2 = new Button("Play Game");
		Button btnPhase1PlayGame3 = new Button("Play Game");
		Button btnPhase1PlayGame4 = new Button("Play Game");
		Label lblWinnerPhase1Game1 = new Label("	1	");
		Label lblWinnerPhase1Game2 = new Label("	3	");
		Label lblWinnerPhase1Game3 = new Label("	5	");
		Label lblWinnerPhase1Game4 = new Label("	7	");

		gpPhase.add(lblPhase0Participent1, 0, 0);
		gpPhase.add(lblPhase0Participent2, 0, 2);
		gpPhase.add(lblPhase0Participent3, 0, 4);
		gpPhase.add(lblPhase0Participent4, 0, 6);
		gpPhase.add(lblPhase0Participent5, 0, 8);
		gpPhase.add(lblPhase0Participent6, 0, 10);
		gpPhase.add(lblPhase0Participent7, 0, 12);
		gpPhase.add(lblPhase0Participent8, 0, 14);

		gpPhase.add(btnPhase1PlayGame1, 1, 1);
		gpPhase.add(btnPhase1PlayGame2, 1, 5);
		gpPhase.add(btnPhase1PlayGame3, 1, 9);
		gpPhase.add(btnPhase1PlayGame4, 1, 13);
		gpPhase.add(lblWinnerPhase1Game1, 2, 1);
		gpPhase.add(lblWinnerPhase1Game2, 2, 5);
		gpPhase.add(lblWinnerPhase1Game3, 2, 9);
		gpPhase.add(lblWinnerPhase1Game4, 2, 13);

		Button btnPhase2PlayGame1 = new Button("Play Game");
		Button btnPhase2PlayGame2 = new Button("Play Game");
		Label lblWinnerPhase2Game1 = new Label("	1	");
		Label lblWinnerPhase2Game2 = new Label("	5	");

		gpPhase.add(btnPhase2PlayGame1, 3, 3);
		gpPhase.add(btnPhase2PlayGame2, 3, 11);
		gpPhase.add(lblWinnerPhase2Game1, 4, 3);
		gpPhase.add(lblWinnerPhase2Game2, 4, 11);

		Button btnFinalPlayGame = new Button("Play Game");
		Label lblWinner = new Label("	1	");

		gpPhase.add(btnFinalPlayGame, 5, 7);
		gpPhase.add(lblWinner, 6, 7);

		Label[] lblPlayers8 = { lblParticipent1, lblParticipent2, lblParticipent3, lblParticipent4, lblParticipent5,
				lblParticipent6, lblParticipent7, lblParticipent8 };

		Label[] lblParticipants = { lblPhase0Participent1, lblPhase0Participent2, lblPhase0Participent3,
				lblPhase0Participent4, lblPhase0Participent5, lblPhase0Participent6, lblPhase0Participent7,
				lblPhase0Participent8, lblWinnerPhase1Game1, lblWinnerPhase1Game2, lblWinnerPhase1Game3,
				lblWinnerPhase1Game4, lblWinnerPhase2Game1, lblWinnerPhase2Game2, lblWinner };

		for (int i = 0; i < lblPlayers8.length; i++) {
			lblPlayers8[i].setBorder(new Border(
					new BorderStroke(Color.RED, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
			lblPlayers8[i]
					.setBackground(new Background(new BackgroundFill(Color.BLUE, CornerRadii.EMPTY, Insets.EMPTY)));
			lblPlayers8[i].setTextFill(Color.WHITE);
		}

		for (int i = 0; i < lblParticipants.length; i++) {
			lblParticipants[i].setBorder(new Border(
					new BorderStroke(Color.ORANGE, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
			lblParticipants[i]
					.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));
			lblParticipants[i].setTextFill(Color.WHITE);
		}

		vbParticipents.getChildren().addAll(lblParticipent1, lblParticipent2, lblParticipent3, lblParticipent4,
				lblParticipent5, lblParticipent6, lblParticipent7, lblParticipent8);

		vbChooseGame.getChildren().addAll(rbSportTypeSoccer, rbSportTypeBasketball, rbSportTypeTennis);

		brRoot.setRight(vbChooseGame);
		vbChooseGame.setAlignment(Pos.CENTER_LEFT);

		brRoot.setLeft(vbParticipents);
		vbParticipents.setAlignment(Pos.CENTER_LEFT);

		spRoot.getChildren().addAll(gpAddPlayers, gpPhase);
		gpPhase.setAlignment(Pos.CENTER_LEFT);
		gpPhase.setVisible(false);

		BorderPane bpSoccer = new BorderPane();

		VBox vbSoccerScene = new VBox();
		vbSoccerScene.setPadding(new Insets(10));
		vbSoccerScene.setSpacing(10);

		HBox hbSoccer1 = new HBox();
		hbSoccer1.setPadding(new Insets(10));
		hbSoccer1.setSpacing(10);

		HBox hbSoccer2 = new HBox();
		hbSoccer2.setPadding(new Insets(10));
		hbSoccer2.setSpacing(10);

		HBox hbSoccer3 = new HBox();
		hbSoccer3.setPadding(new Insets(10));
		hbSoccer3.setSpacing(10);

		HBox hbSoccer4 = new HBox();
		hbSoccer4.setPadding(new Insets(10));
		hbSoccer4.setSpacing(10);

		Label lblSoccerHeadline = new Label("Soccer");
		Label lblSoccerPlayer1 = new Label("	1	");
		Label lblSoccerPlayer2 = new Label("	2	");
		Label lblSoccerHalf1 = new Label("Half 1");
		Label lblSoccerHalf2 = new Label("Half 2");
		Label lblSoccerOvertime = new Label("Overtime");
		Label lblSoccerPenalties = new Label("Penalties");

		TextField tfSoccerTeamAScoreHalf1 = new TextField();
		TextField tfSoccerTeamBScoreHalf1 = new TextField();
		TextField tfSoccerTeamAScoreHalf2 = new TextField();
		TextField tfSoccerTeamBScoreHalf2 = new TextField();
		TextField tfSoccerTeamAScoreOvertime = new TextField();
		TextField tfSoccerTeamBScoreOvertime = new TextField();
		TextField tfSoccerTeamAScorePenalties = new TextField();
		TextField tfSoccerTeamBScorePenalties = new TextField();

		Button btnSoccerSubmitScore = new Button("Submit Score");
		Button btnSoccerDone = new Button("Done");

		hbSoccer1.getChildren().addAll(lblSoccerHalf1, lblSoccerHalf2, lblSoccerOvertime, lblSoccerPenalties);
		hbSoccer2.getChildren().addAll(lblSoccerPlayer1, tfSoccerTeamAScoreHalf1, tfSoccerTeamAScoreHalf2,
				tfSoccerTeamAScoreOvertime, tfSoccerTeamAScorePenalties);
		hbSoccer3.getChildren().addAll(lblSoccerPlayer2, tfSoccerTeamBScoreHalf1, tfSoccerTeamBScoreHalf2,
				tfSoccerTeamBScoreOvertime, tfSoccerTeamBScorePenalties);
		hbSoccer4.getChildren().addAll(btnSoccerSubmitScore, btnSoccerDone);

		vbSoccerScene.getChildren().addAll(hbSoccer1, hbSoccer2, hbSoccer3);
		bpSoccer.setCenter(vbSoccerScene);
		bpSoccer.setTop(lblSoccerHeadline);
		bpSoccer.setBottom(hbSoccer4);

		Stage gameStage = new Stage();
		Scene gameScene = new Scene(bpSoccer, 500, 300);
		
		

		btnAddParticipet.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				for (ViewListeners l : allListeners) {
					l.addParticipantToModel(tfPlayerName.getText());
				}
			}
		});

		btnStartTournament.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				for (ViewListeners l : allListeners) {
					l.startTournamentInModel(tglGames.getSelectedToggle().getClass().getName());
				}
				gpAddPlayers.setVisible(false);
				vbChooseGame.setVisible(false);
				vbParticipents.setVisible(false);
				gpPhase.setVisible(true);
			}
		});

		btnPhase1PlayGame1.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				gameStage.setScene(gameScene);
				gameStage.show();

			}
		});
				
		
		

		gpPhase.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				int col;
				int row;
				
				for (Node node : gpPhase.getChildren()) {
					if (node instanceof Button) {
						col = (GridPane.getColumnIndex(node));
						row = (GridPane.getRowIndex(node));
						
						getParticipentsToGame(gpPhase, row, col);
						
						
						//lblSoccerPlayer1.setText(gpPhase.getChildren().);
					}
					
					

				}
			}
		});

		Scene scene = new Scene(brRoot, 1000, 700);
		theStage.setScene(scene);
		theStage.show();
	}

	@Override
	public void start(Stage theStage) throws Exception {
		// TODO Auto-generated method stub

	}
	public Node[] getParticipentsToGame(GridPane gp,int row,int col) {
		
		Node[] nodes = new Node[2];
		
		for (Node node : gp.getChildren()) {
			if ((gp.getColumnIndex(node) == (col-1)) && ((gp.getRowIndex(node) == (row-1)))) {
				nodes[0] = node;
			}
			else if ((gp.getColumnIndex(node) == (col-1)) && ((gp.getRowIndex(node) == (row+1)))) {
				nodes[1] = node;
			}
		}
		return nodes;
	}

}
