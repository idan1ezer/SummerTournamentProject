package model;



public class Soccer extends Game {
	private static int parts = 3;
	private boolean overtime;
	private boolean penalties;

	public Soccer() {
		super();
	}

	
	@Override
	protected Participant getLoser() {
		if (penalties)
			return min(teamA.getScore().get(3), teamB.getScore().get(3));
		else if (overtime)
			return min(teamA.getScore().get(2), teamB.getScore().get(2));
		else
			return min(teamA.getScore().get(1), teamB.getScore().get(1));
			
	}

	private Participant min(int finalScoreTeamA, int finalScoreTeamB) {
		if(finalScoreTeamA > finalScoreTeamB)
			return teamB;
		else
			return teamA;
	}


	


	@Override
	protected void addScoreTeamA(int scoreA) {
		//each score conditions
	}


	@Override
	protected void addScoreTeamB(int scoreB) {
		//each score conditions
	}

}
