package Games;

import java.util.Scanner;

public class Basketball extends Game {
	private static int parts = 4;

	@Override
	protected void startGame(Participant participant1, Participant participant2) {
		Scanner scan = new Scanner(System.in);
		
		participants.add(participant1);
		participants.add(participant2);

		for (int j = 0; j < 4; j++) {
			// System.out.println("Enter team " + participants.get(j).getName() + " score in " + (i + 1) + " half");
			participants.get(0).getScore().add(scan.nextInt());
			participants.get(1).getScore().add(scan.nextInt());
		}		
	}

	@Override
	protected Participant getLoser() {
		int finalScoreTeamA = 0;
		int finalScoreTeamB = 0;
		
		for (int i = 0; i < 4; i++) {
			finalScoreTeamA += participants.get(0).getScore().get(i);
			finalScoreTeamB += participants.get(1).getScore().get(i);
		}
		return min(finalScoreTeamA, finalScoreTeamB);		
	}

	private Participant min(Integer finalScoreTeamA, Integer finalScoreTeamB) {
		if(finalScoreTeamA > finalScoreTeamB)
			return participants.get(1);
		else
			return participants.get(0);
	}
}
