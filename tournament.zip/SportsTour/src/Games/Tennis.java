package Games;

public class Tennis extends Game {
	private static int parts = 5;
	


	@Override
	protected void startGame(Participant participant, Participant participant2) {
		// TODO Auto-generated method stub
		
	}


	@Override
	protected Participant getLoser() {
		// TODO Auto-generated method stub
		return null;
	}

}
