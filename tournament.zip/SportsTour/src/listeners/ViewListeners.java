package listeners;

public interface ViewListeners {

	void addParticipantToModel(String text);

	void startTournamentInModel(String name);

}
