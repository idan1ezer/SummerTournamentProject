package model;

public class Soccer extends Game {
	private static int parts = 4;
	private boolean overtime;
	private boolean penalties;

	public Soccer() {
		super();
	}

	@Override
	protected Participant getLoser() {
		if (penalties) {
			return min(teamA.getScore().get(3), teamB.getScore().get(3));
		}
		else if (overtime)
			return min(teamA.getScore().get(2), teamB.getScore().get(2));
		else
			return min(teamA.getScore().get(1), teamB.getScore().get(1));

		// reset score vector

	}

	private Participant min(int finalScoreTeamA, int finalScoreTeamB) {
		if (finalScoreTeamA > finalScoreTeamB)
			return teamB;
		else
			return teamA;
	}

	@Override
	public int addScoreToTeams(int scoreA, int scoreB) throws Exception {
		addScoreToTeam(teamA, scoreA);
		addScoreToTeam(teamB, scoreB);

		if (teamA.getScore().size() >= 2) {
			enableOvertimeOrPenalties();
			checkForWinner(teamA.getScore().size());
		}
		return teamA.getScore().size();
	}

	public void enableOvertimeOrPenalties() {
		
		if (teamA.getScore().get(1) == teamB.getScore().get(1))
			overtime = true;
		
		if (teamA.getScore().size()==3&&teamA.getScore().get(2) == teamB.getScore().get(2)) {
			overtime = false;
			penalties = true;
		}
	}

	private boolean checkForWinner(int partNum) {
		int fixPartNum = partNum - 1;
		if (teamA.getScore().get(fixPartNum) != teamB.getScore().get(fixPartNum)) {
		System.out.println("checkForWinner");
		return true;
		}
		else if (teamA.getScore().get(1) == teamB.getScore().get(1)) {
				overtime = true;
		}
		else if (teamA.getScore().size()==3&&teamA.getScore().get(2) == teamB.getScore().get(2)) {
			overtime = false;
			penalties = true;
		}
		return false;
		
	}

	private void addScoreToTeam(Participant team, int score) throws Exception {
		if (score >= 0) {
			if (team.getScore().size() == 0)
				team.addScore(score);
			else if (team.getScore().size() == 1) {
				if (score >= team.getScore().get(0))
					team.addScore(score);
				else {
					throw new Exception("Score must be higher than first half");
				}
			} else if (team.getScore().size() == 2) {
				if (score >= team.getScore().get(1))
					team.addScore(score);
				else {
					throw new Exception("Score must be higher than second half");
				}
			} else if (team.getScore().size() == 3) {
				if (score <= 5)
					team.addScore(score);
				else {
					throw new Exception("Penalties score must be lower or equal to 5");
				}
			}

		}
	}

	@Override
	public String toString() {

		return "Soccer";
	}

	@Override
	protected void checkForWinner() {
		// TODO Auto-generated method stub

	}
}
