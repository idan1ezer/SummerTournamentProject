package controller;

import java.util.Vector;

import javax.swing.JOptionPane;

import javafx.scene.control.Label;
import model.Participant;
import model.Tournament;
import view.TournamentView;
import listeners.TournamentListener;
import listeners.ViewListener;

public class TournamentController implements TournamentListener, ViewListener {
	private Tournament tournament;
	private TournamentView view;

	public TournamentController(Tournament tournament, TournamentView view) {
		this.tournament = tournament;
		this.view = view;
		view.registerListeners(this);
		tournament.registerListeners(this);
	}

	@Override
	public void fireParticipantsToUI(Vector<Participant> participants) {
		for (int i = 0; i < participants.size(); i++) {
			view.getAllTournamentNameLabels()[i].setText(participants.get(i).getName());
		}
	}

	@Override
	public void addParticipantToModel(String name) {
		try {
			tournament.addParticipantToTournament(name);
		} catch (Exception e) {
			view.getLblException().setText(e.getMessage());
			view.getLblException().setVisible(true);
		}

	}

	@Override
	public void startTournamentInModel(String gameType) {
		try {
			tournament.setGameType(gameType);
			tournament.startTournament();
		} catch (Exception e) {
			view.getLblException().setText(e.getMessage());
			view.getLblException().setVisible(true);
		}

	}

	@Override
	public void submitPartScoreInModel(int gameIndex, int scoreTeamA, int scoreTeamB) {
		tournament.submitPartScore(gameIndex, scoreTeamA, scoreTeamB);
	}

	@Override
	public void fireAddedPlayerToUI(String name) {
		boolean flag = false;
		for (int i = 0; i < view.getParticipantList().length && !flag; i++) {
			if (view.getParticipantList()[i].getText().isEmpty()) {
				flag = true;
				view.getParticipantList()[i].setText(name);
			}
		}
	}

	@Override
	public void startGameInModel(int gameIndex) {
		String participantA = null;
		String participantB = null;
		if (gameIndex <= 3) {
			participantA = tournament.getPhase().get(0).getGames().get(gameIndex).getTeamA().getName();
			participantB = tournament.getPhase().get(0).getGames().get(gameIndex).getTeamB().getName();
		} else if (gameIndex <= 5) {
			participantA = tournament.getPhase().get(1).getGames().get(gameIndex - 4).getTeamA().getName();
			participantB = tournament.getPhase().get(1).getGames().get(gameIndex - 4).getTeamB().getName();
		} else if (gameIndex <= 6) {
			participantA = tournament.getPhase().get(2).getGames().get(0).getTeamA().getName();
			participantB = tournament.getPhase().get(2).getGames().get(0).getTeamB().getName();
		}

		setParticipantsLabels(participantA, participantB);
	}

	private void setParticipantsLabels(String A, String B) {
		if (tournament.getGameType().getClass().getName() == "model.Soccer") {
			view.getTeamLabels()[0].setText(A);
			view.getTeamLabels()[1].setText(B);
		} else if (tournament.getGameType().getClass().getName() == "model.Basketball") {
			view.getTeamLabels()[2].setText(A);
			view.getTeamLabels()[3].setText(B);
		} else {
			view.getTeamLabels()[4].setText(A);
			view.getTeamLabels()[5].setText(B);
		}

		// CHANGE THE model. SHIT
	}

	@Override
	public void fireNextTextFieldsToUI(int partNum) {
		System.out.println("in fire");
		// maybe need to check has next method because not all games has the same number
		// of text fields
		enableGameNextTextFields(partNum);

	}

	private void enableGameNextTextFields(int partNum) {
		System.out.println("in enbale method");
		if (partNum != tournament.getPhase().get(0).getGames().get(0).getParts()) {
			System.out.println("in if 1");
			System.out.println(tournament.getGameTypeName());
			if (tournament.getGameTypeName()==("Soccer")) {
				System.out.println("in if 2");
				for (int i = 0; i < view.getSoccerTextFields().length; i++) {
					view.getSoccerTextFields()[i].setDisable(true);
					System.out.println(partNum+"+"+i);
				}
				
				view.getSoccerTextFields()[partNum * 2].setDisable(false);
				view.getSoccerTextFields()[partNum * 2 + 1].setDisable(false);
			} else if (tournament.getGameTypeName().toString().equals("Basketball")) {
				for (int i = 0; i < view.getBasketballTextFields().length; i++) {
					view.getBasketballTextFields()[i].setDisable(true);
				}
				view.getBasketballTextFields()[partNum * 2].setDisable(false);
				view.getBasketballTextFields()[partNum * 2 + 1].setDisable(false);
			} else {
				for (int i = 0; i < view.getTennisTextFields().length; i++) {
					view.getTennisTextFields()[i].setDisable(true);
				}
				view.getTennisTextFields()[partNum * 2].setDisable(false);
				view.getTennisTextFields()[partNum * 2 + 1].setDisable(false);
			}

		}

	}

}
